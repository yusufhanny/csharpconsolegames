﻿namespace Tetris
{
    public enum TetrisGameInput
    {
        None = 0,
        Left = 1,
        Right = 2,
        Down = 3,
        Rotate = 4,
        Exit = 99,
    }
}
