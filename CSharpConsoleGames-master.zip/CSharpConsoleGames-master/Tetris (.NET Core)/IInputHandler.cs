﻿namespace Tetris
{
    public interface IInputHandler
    {
        TetrisGameInput GetInput();
    }
}