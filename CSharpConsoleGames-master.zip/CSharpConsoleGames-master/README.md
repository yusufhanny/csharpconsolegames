C# Console Games
================

Source code for some C# console games with video explanation **in Bulgarian**

* Cars (2012): http://www.youtube.com/watch?v=bQexyufgclY
* PingPong (2012): http://www.youtube.com/watch?v=DmkqnjsNKZM
* Snake (2012): http://www.youtube.com/watch?v=dXng0W0R_Ks
* Tron (2013): http://www.youtube.com/watch?v=yccxWRsQBB0
* Tetris (2014): https://www.youtube.com/watch?v=0-WOuN0qqI0
* Tetris (.NET Core) (2019)
  * Creating Tetris part 1 - https://youtu.be/_-JyqwaLjVM
  * Creating Tetris part 2 - https://youtu.be/lWsm3ZTSnt0
  * Creating Tetris part 3 - https://youtu.be/VBxFekjsGPc
  * Refactoring Tetris with OOP part 1 - https://youtu.be/SmDNHr3uL-E
  * Refactoring Tetris with OOP part 2 - https://youtu.be/v2mEpgxSB6A
  * Refactoring Tetris with OOP part 3 - https://youtu.be/IjO38LeZuHY
